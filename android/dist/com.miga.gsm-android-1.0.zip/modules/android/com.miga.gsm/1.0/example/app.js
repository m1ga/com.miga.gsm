var gsm = require('com.miga.gsm');

var win = Ti.UI.createWindow({
	backgroundColor: '#fff'
});

gsm.getData({
    success: function(e){
        console.log(e);
    }
});
win.open();
